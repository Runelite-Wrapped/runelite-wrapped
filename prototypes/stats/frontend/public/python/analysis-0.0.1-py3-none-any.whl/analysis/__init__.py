from analysis.main import main as run
