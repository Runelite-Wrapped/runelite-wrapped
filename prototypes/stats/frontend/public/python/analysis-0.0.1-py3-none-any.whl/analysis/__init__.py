from analysis.main import main as run
from analysis.main import get_tile_data, get_energy_data, calculate_tile_count