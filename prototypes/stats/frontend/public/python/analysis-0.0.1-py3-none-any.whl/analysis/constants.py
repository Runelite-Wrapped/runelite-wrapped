import os

DB_FILE = os.getenv("DB_FILE", "/stats.db")
